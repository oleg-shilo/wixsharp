// bstrapper.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "ShellAPI.h"
#include "ShlWAPI.h"
#include "Resource.h"

#include "comdef.h"

#define MAX_KEY_LENGTH 255
#define MAX_VALUE_NAME 16383

class OutputStream
{
    wstring name;
    ofstream* file;

public:
    ~OutputStream()
    {
        delete file;
    }
    
    OutputStream(wstring name)
    {
		string asciName = (LPCSTR)_bstr_t(name.c_str()); //to satisfy VS6.0
        this->name = name;
        this->file = new ofstream(asciName.c_str(), ios::out | ios::binary);
    }

    void SetOffset(long offset, bool fromEnd = false)
    {
        file->seekp(fromEnd ? -offset : offset, fromEnd ? ios::end : ios::beg);
    }

    void WriteData(string& data)
    {
        file->write((char*)data.data(), data.size());
    }

    void WriteString(wstring data)
    {
        long size = data.length()*sizeof(WCHAR);
        file->write((char*)data.data(), size);
    }

    void WriteLong(long data)
    {
        file->write((char*)&data, (streamsize)sizeof(data));
    }

    void WriteByte(char data)
    {
        file->write(&data, (streamsize)sizeof(data));
    }

    static void Write(wstring fileName, string data)
    {
        string asciFileName = (LPCSTR)_bstr_t(fileName.c_str());
        ofstream file(asciFileName.c_str(), ios::out | ios::binary);
        file.write((char*)data.data(), (streamsize)data.size());
    }
};

class Shell
{
public:
    static void RunApp(wstring app, wstring params)
    {
        SHELLEXECUTEINFOW sei = { sizeof(sei) };
        sei.fMask = SEE_MASK_FLAG_DDEWAIT;
        sei.nShow = SW_SHOWNORMAL;
        sei.lpFile = app.c_str();
        if (params.length() != 0)
            sei.lpParameters = params.c_str();
        sei.fMask = SEE_MASK_NOCLOSEPROCESS;  //ensures hProcess gets the process handle

        ShellExecuteExW(&sei);

        WaitForSingleObject(sei.hProcess, INFINITE);
    }
    
    static void RunApp(wstring app)
    {
        SHELLEXECUTEINFOW sei = { sizeof(sei) };
        sei.fMask = SEE_MASK_FLAG_DDEWAIT;
        sei.nShow = SW_SHOWNORMAL;
        sei.lpFile = app.c_str();
        sei.fMask = SEE_MASK_NOCLOSEPROCESS;  //ensures hProcess gets the process handle

        ShellExecuteExW(&sei);

        WaitForSingleObject(sei.hProcess, INFINITE);
    }

    static bool DelFile(wstring file)
    {
        return DeleteFileW(file.c_str()) ? true : false;
    }
};

class Path
{
public:
    static wstring Combine(wstring path1, wstring path2)
    {
	    WCHAR buf[MAX_PATH*2];
	    GetCurrentDirectoryW(MAX_PATH*2, buf);
    		
	    PathCombineW(buf, path1.c_str(), path2.c_str());
    	
	    return wstring(buf);
    }
    
    static wstring GetFullPath(wstring path)
    {
        if (PathIsRelativeW(path.c_str()))
        {
            return Path::Combine(Path::CurrentDirectory(), path);
        }
        else
        {
	        return path;
        }
    }

    static wstring GetFileName(wstring path)
    {
        return PathFindFileNameW(path.c_str());
    }

    static wstring CurrentDirectory()
    {
	    WCHAR dir[MAX_PATH*2];
	    GetCurrentDirectoryW(MAX_PATH*2, dir); 
    	
	    return wstring(dir);
    }

    static bool FileExists(wstring path)
    {
        return PathFileExistsW(path.c_str()) ? true : false;
    }

    static bool DirectoryExists(wstring path)
    {
        return FileExists(path);
    }
    
    static void CreateDirectory(wstring directory)
    {
        ::CreateDirectoryW(directory.c_str(), NULL);
    }

    static wstring GetTempDir()
    {
	    WCHAR buf[MAX_PATH*2];
        GetTempPathW(MAX_PATH*2, buf);
    	
	    return wstring(buf);
    }
};

class Utils
{
public: 
    static bool StartWith(wstring data, wstring pattern)
    {
        for(UINT i = 0; i < pattern.length(); i++)
            if (pattern[i] != data[i])
                return false;

        return true;
    }

    static wstring Substring(wstring data, int index)
    {
        wstring retval;
        retval = (data.c_str() + index);

        return retval;
    }

    static vector<wstring> Split(wstring data, WCHAR delimiter)
    {
        vector<wstring> retval;
        retval.push_back(L"");
        UINT index = 0;

        for(UINT i = 0; i < data.length(); i++)
            if (data[i] == delimiter)
            {
                if (i+1 < data.length() && data[i+1] == delimiter) //not a delimiter but a char with the same value as the delimiter
                {
                    retval[index] += data[i++]; //skip the next character
                }
                else
                {
                    retval.push_back(L"");
                    index++;
                }
            }
            else
            {
                retval[index] += data[i];
            }

        return retval;
    }

    static wstring DataToString(string str)
    {
        wstring retval;
        retval.resize(str.length()*sizeof(WCHAR));
        memcpy((void*)retval.data(), str.data(), str.length());
        return retval; 
    }

    static string StringToData(wstring data)
    {
        string retval;
        retval.resize(data.length()*sizeof(WCHAR));
        memcpy((void*)retval.data(), data.data(), retval.length());
        return retval; 
    }
};


class RegKey
{
public:
    static bool ValueExists(wstring path)
    {
        vector<wstring> tokens = Utils::Split(path, L':');
        return ValueExists(tokens[0], tokens[1], tokens[2]);
    }
    
    static bool ValueExists(wstring key, wstring path, wstring value)
    {
        HKEY hOpenedKey;
        HKEY hKey;

        if (key == L"HKCU")
            hKey = HKEY_CURRENT_USER;
        else if(key == L"HKLM")
            hKey = HKEY_LOCAL_MACHINE;
        else if(key == L"HKCR")
            hKey = HKEY_CLASSES_ROOT;
        else if(key == L"HKU")
            hKey = HKEY_USERS;

        if( RegOpenKeyExW(hKey, path.c_str(), 0, KEY_READ, &hOpenedKey) == ERROR_SUCCESS)
        {
            if (value == L"")
                return true; //default value
            else
                return QueryKeyValue(hOpenedKey, value);
        }

        return false;
    }

private:
    static bool QueryKeyValue(HKEY hKey, wstring valueName) 
    { 
        WCHAR    achClass[MAX_PATH] = L"";  // buffer for class name 
        DWORD    cchClassName = MAX_PATH;  // size of class string 
        DWORD    cSubKeys=0;               // number of subkeys 
        DWORD    cbMaxSubKey;              // longest subkey size 
        DWORD    cchMaxClass;              // longest class string 
        DWORD    cValues;              // number of values for key 
        DWORD    cchMaxValue;          // longest value name 
        DWORD    cbMaxValueData;       // longest value data 
        DWORD    cbSecurityDescriptor; // size of security descriptor 
        FILETIME ftLastWriteTime;      // last write time 
     
        DWORD i, retCode; 
     
        WCHAR  achValue[MAX_VALUE_NAME]; 
        DWORD cchValue = MAX_VALUE_NAME; 
     
        // Get the class name and the value count. 
        retCode = RegQueryInfoKeyW(
            hKey,                    // key handle 
            achClass,                // buffer for class name 
            &cchClassName,           // size of class string 
            NULL,                    // reserved 
            &cSubKeys,               // number of subkeys 
            &cbMaxSubKey,            // longest subkey size 
            &cchMaxClass,            // longest class string 
            &cValues,                // number of values for this key 
            &cchMaxValue,            // longest value name 
            &cbMaxValueData,         // longest value data 
            &cbSecurityDescriptor,   // security descriptor 
            &ftLastWriteTime);       // last write time 
     
          // Enumerate the key values. 

            printf( "\nNumber of values: %d\n", cValues);

            for (i=0, retCode=ERROR_SUCCESS; i<cValues; i++) 
            { 
                cchValue = MAX_VALUE_NAME; 
                achValue[0] = '\0'; 
                retCode = RegEnumValueW(hKey, i, 
                    achValue, 
                    &cchValue, 
                    NULL, 
                    NULL,
                    NULL,
                    NULL);
     
                if (retCode == ERROR_SUCCESS ) 
                { 
                    if (_wcsicmp(valueName.c_str(), achValue) == 0)
                    //if (valueName == achValue)
                        return true;
                    //_tprintf(TEXT("(%d) %s\n"), i+1, achValue); 
                } 
            }

            return false;
        }
};

class Resources
{
public:
    static string Read(int resourceId, LPCWSTR resourceType, HINSTANCE hInstance)
    {
        string buffer;


	    HRSRC resInfo = ::FindResourceW(hInstance, MAKEINTRESOURCEW( resourceId ), resourceType);
	    HGLOBAL resHandle = ::LoadResource(hInstance, resInfo);
	    DWORD resSize = ::SizeofResource(hInstance, resInfo);
	    BYTE* pData = (BYTE*)::LockResource(resHandle);

	    buffer.resize(resSize);
	    memcpy((char*)buffer.data(), pData, resSize);

	    UnlockResource(resHandle);	

        return buffer;
    }

    static bool ReplaceResource(wstring file, wstring resType, int resId, string data)
    {
        return ReplaceResource(file, resType, resId, MAKELANGID(LANG_ENGLISH, SUBLANG_ENGLISH_US), data);
    }

    static bool ReplaceResource(wstring file, wstring resType, int resId, WORD language, string data)
    {
        HANDLE h = ::BeginUpdateResourceW(file.c_str(), FALSE);
        if(h == NULL || !::UpdateResourceW(h, resType.c_str(), MAKEINTRESOURCEW(resId), language, (LPVOID)data.data(), data.length()) )
        {
            return false;
        }
        ::EndUpdateResource(h, FALSE); // write changes 
        return true;
    }
};


void ProcessWinResources(wstring& msiFile1, wstring& msiFile2, wstring& regKey, HINSTANCE hInstance)
{
    wstring tempDir =  Path::Combine(Path::GetTempDir(), L"Wix#");

    if (!Path::DirectoryExists(tempDir))
        Path::CreateDirectory(tempDir);
    
    string msiData1 = Resources::Read(IDR_CUSTOM_APP1_DATA, L"Custom", hInstance); 
    wstring fileName = Utils::DataToString(Resources::Read(IDR_CUSTOM_APP1_NAME, L"Custom", hInstance));
    
    msiFile1 = Path::Combine(tempDir, fileName);
    OutputStream::Write(msiFile1, msiData1);

    string msiData2 = Resources::Read(IDR_CUSTOM_APP2_DATA, L"Custom",hInstance); 
    fileName = Utils::DataToString(Resources::Read(IDR_CUSTOM_APP2_NAME, L"Custom", hInstance));
    
    msiFile2 = Path::Combine(tempDir, fileName);
    OutputStream::Write(msiFile2, msiData2);
     
    regKey = Utils::DataToString(Resources::Read(IDR_CUSTOM_CONDITION, L"Custom", hInstance)); 
}

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
 	wstring msiFile1, msiFile2;
    wstring regKey;

    ProcessWinResources(msiFile1, msiFile2, regKey, hInstance);
   
    wstring msiParams = PathGetArgsW(GetCommandLineW());


	string asciName = (LPCSTR)_bstr_t(msiFile1.c_str()); //to satisfy VS6.0
	asciName = (LPCSTR)_bstr_t(msiFile2.c_str()); //to satisfy VS6.0
	asciName = (LPCSTR)_bstr_t(regKey.c_str()); //to satisfy VS6.0

    if (!RegKey::ValueExists(regKey))
	    Shell::RunApp(msiFile1, msiParams);

    
	Shell::RunApp(msiFile2, msiParams);

	return 0;
}
