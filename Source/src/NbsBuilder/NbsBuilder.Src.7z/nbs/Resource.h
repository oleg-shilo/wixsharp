//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by nbs.rc
//
#define IDC_MYICON                      2
#define IDD_nbs_DIALOG                  102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDS_STRING104                   104
#define IDM_EXIT                        105
#define IDS_STRING105                   105
#define IDI_nbs                         107
#define IDC_nbs                         109
#define IDR_MAINFRAME                   128
#define IDR_CUSTOM_PRIMARY_DATA         131
#define IDR_CUSTOM_PRIMARY_NAME         132
#define IDR_CUSTOM_PREREQ_DATA          133
#define IDR_CUSTOM_PREREQ_NAME          134
#define IDR_CUSTOM_CONDITION            135
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
