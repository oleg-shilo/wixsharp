﻿using Microsoft.Deployment.WindowsInstaller;
using System;
using System.Windows.Forms;

public class CustomActions
{
    [CustomAction]
    public static ActionResult ValidateLicenceKey(Session session)
    {
        return ActionResult.Success;
    }

    [CustomAction]
    public static ActionResult MyAction(Session session)
    {
        MessageBox.Show("Hello World! (CLR: v" + Environment.Version + ")", "Embedded Managed CA (" + (Is64BitProcess ? "x64" : "x86") + ")");
        session.Log("Begin MyAction Hello World");

        return ActionResult.Success;
    }

    public static bool Is64BitProcess
    {
        get { return IntPtr.Size == 8; }
    }
}