﻿using System;
using System.Windows.Forms;
using Microsoft.Deployment.WindowsInstaller;
using WixSharp;

namespace WixSharp_Setup1
{
    class Program
    {
        static void Main()
        {
            var project = new Project("CustomActionTest",
                 new ManagedAction(CustomActions.MyAction)
                 {
                     ActionAssembly = typeof(CustomActions).Assembly.Location,
                 });

            project.UI = WUI.WixUI_ProgressOnly;

            Compiler.BuildMsi(project);
        }
    }
}

