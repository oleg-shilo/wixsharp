﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Security.Principal;
using System.Windows;
using WixSharp;
using WixToolset.BootstrapperApplicationApi;

public class ManagedBA : BootstrapperApplication
{
    public ManagedBA()
    {
    }

    public IEngine Engine => base.engine;
    public IBootstrapperCommand Command;
    internal IBootstrapperApplicationData BAManifest { get; private set; }

    protected override void OnCreate(CreateEventArgs args)
    {
        base.OnCreate(args);
        Command = args.Command;
        BAManifest = new BootstrapperApplicationData();
    }

    /// <summary>
    /// Entry point that is called when the bootstrapper application is ready to run.
    /// </summary>
    protected override void Run()
    {
        new MainView(this).ShowDialog();
        engine.Quit(0);
    }
}

public class MainViewModel : INotifyPropertyChanged
{
    protected void OnPropertyChanged(string propertyName)
    {
        if (PropertyChanged != null)
            PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
    }

    public event PropertyChangedEventHandler PropertyChanged;

    public IntPtr ViewHandle;

    public MainViewModel(ManagedBA bootstrapper)

    {
        this.IsBusy = false;

        this.Bootstrapper = bootstrapper;
        this.Bootstrapper.Error += this.OnError;
        this.Bootstrapper.ApplyComplete += this.OnApplyComplete;
        this.Bootstrapper.DetectBegin += Bootstrapper_DetectBegin;
        this.Bootstrapper.DetectPackageComplete += this.OnDetectPackageComplete;
        this.Bootstrapper.PlanComplete += this.OnPlanComplete;

        this.Bootstrapper.Engine.Detect();

        var cmd = this.Bootstrapper.Command.CommandLine;

        if (cmd != null)
        {
            if (cmd.Contains("-install") || cmd.Contains("-i") || cmd.Contains("/install") || cmd.Contains("/i"))
                this.InstallExecute();
            else if (cmd.Contains("-uninstall") || cmd.Contains("-u") || cmd.Contains("/uninstall") || cmd.Contains("/u"))
                this.InstallExecute();
            else if (cmd.Contains("-all") || cmd.Contains("/all"))
                showAllCommands = true;
        }
    }

    bool showAllCommands = false;

    RegistrationType detecteRegistrationType = RegistrationType.None;

    void Bootstrapper_DetectBegin(object sender, DetectBeginEventArgs e)
    {
        detecteRegistrationType = e.RegistrationType;
    }

    public void ShowLog()
    {
        try
        {
            using (var process = new Process())
            {
                process.StartInfo.FileName = new Uri(Bootstrapper.Engine.GetVariableString("WixBundleLog")).ToString();
                process.StartInfo.UseShellExecute = true;
                process.StartInfo.Verb = "open";

                process.Start();
            }
        }
        catch { }
    }

    void OnError(object sender, ErrorEventArgs e)
    {
        MessageBox.Show(e.ErrorMessage);
    }

    bool installEnabled;

    public bool InstallEnabled
    {
        get { return installEnabled; }
        set
        {
            installEnabled = value;
            OnPropertyChanged("InstallEnabled");
        }
    }

    string userInput = "User input content...";

    public string UserInput
    {
        get => userInput;

        set
        {
            userInput = value;
            OnPropertyChanged("UserInput");
        }
    }

    bool uninstallEnabled;

    public bool UninstallEnabled
    {
        get { return uninstallEnabled; }
        set
        {
            uninstallEnabled = value;
            OnPropertyChanged("UninstallEnabled");
        }
    }

    bool isThinking;

    public bool IsBusy
    {
        get { return isThinking; }
        set
        {
            isThinking = value;
            OnPropertyChanged("IsBusy");
        }
    }
    public ManagedBA Bootstrapper { get; set; }

    public void InstallExecute()
    {
        IsBusy = true;
        InstallEnabled = false;
        UninstallEnabled = false;

        Bootstrapper.Engine.SetVariableString("UserInput", UserInput, false);
        Bootstrapper.Engine.Plan(LaunchAction.Install);
    }

    public void UninstallExecute()
    {
        IsBusy = true;
        InstallEnabled = false;
        UninstallEnabled = false;

        Bootstrapper.Engine.Plan(LaunchAction.Uninstall);
    }

    public void ExitExecute()
    {
        //Dispatcher.BootstrapperDispatcher.InvokeShutdown();
    }

    /// <summary>
    /// Method that gets invoked when the Bootstrapper ApplyComplete event is fired.
    /// This is called after a bundle installation has completed. Make sure we updated the view.
    /// </summary>
    void OnApplyComplete(object sender, ApplyCompleteEventArgs e)
    {
        IsBusy = false;
        InstallEnabled = false;
        UninstallEnabled = false;
    }

    /// <summary>
    /// Method that gets invoked when the Bootstrapper DetectPackageComplete event is fired.
    /// Checks the PackageId and sets the installation scenario. The PackageId is the ID
    /// specified in one of the package elements (msipackage, exepackage, msppackage,
    /// msupackage) in the WiX bundle.
    /// </summary>
    void OnDetectPackageComplete(object sender, DetectPackageCompleteEventArgs e)
    {
        // Debug.Assert(false);
        if (e.PackageId == "MyProductPackageId")
        {
            if (e.Cached)
            {
                InstallEnabled = detecteRegistrationType == RegistrationType.None;
                UninstallEnabled = !InstallEnabled;
            }
            else
            {
                if (e.State == PackageState.Absent)
                {
                    InstallEnabled = true;
                }
                else if (e.State == PackageState.Present)
                {
                    UninstallEnabled = true;
                }
            }
        }

        if (showAllCommands)
        {
            InstallEnabled = true;
            UninstallEnabled = true;
        }
    }

    /// <summary>
    /// Method that gets invoked when the Bootstrapper PlanComplete event is fired.
    /// If the planning was successful, it instructs the Bootstrapper Engine to
    /// install the packages.
    /// </summary>
    void OnPlanComplete(object sender, PlanCompleteEventArgs e)
    {
        if (e.Status >= 0)
            Bootstrapper.Engine.Apply(ViewHandle);
    }
}