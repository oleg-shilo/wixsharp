﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WixSharp.UI.WPF;

namespace ConsoleApp6
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    public partial class UserControl1 : UserControl, WixSharp.UI.WPF.IWpfDialogContent
    {
        public UserControl1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Initializes the instance of <see cref="T:WixSharp.UI.WPF.IWpfDialogContent" /> and passes the
        /// reference to the parent dialog. It is a good place to adjust layout including parent dialog
        /// element (e.g. disable "Next" button). Or do localization
        /// </summary>
        /// <param name="parentDialog">The parent dialog.</param>
        public void Init(CustomDialogBase parentDialog)
        {
        }
    }
}