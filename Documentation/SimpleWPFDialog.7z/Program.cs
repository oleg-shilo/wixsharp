﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WixSharp;
using WixSharp.UI.Forms;

namespace ConsoleApp6
{
    class Program
    {
        static void Main(string[] args)
        {
            var project = new ManagedProject("MyProduct",
                             new Dir(@"%ProgramFiles%\My Company\My Product",
                             new File(System.Reflection.Assembly.GetExecutingAssembly().Location)));

            project.GUID = new Guid("1ADF5503-75F1-4EBC-ADC5-8260C1808A5B");

            project.ManagedUI = new ManagedUI();
            project.ManagedUI.InstallDialogs.Add<WelcomeDialog>()       // stock WinForm dialog
                                            .Add<FeaturesDialog>()      // stock WinForm dialog
                                                                        .Add<CustomDialogWith<UserControl1>>()    // custom WPF dialog (minimalistic)
                                            .Add<ProgressDialog>()      // stock WinForm dialog
                                            .Add<ExitDialog>();         // stock WinForm dialog

            project.ManagedUI.ModifyDialogs.Add<ProgressDialog>()
                                           .Add<ExitDialog>();

            // project.PreserveTempFiles = true;
            project.BuildMsi();
        }
    }
}